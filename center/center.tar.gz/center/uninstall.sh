#!/bin/sh

rm -rf /koolshare/res/icon-center.png >/dev/null 2>&1
#rm -rf /koolshare/scripts/center_config.sh >/dev/null 2>&1
rm -rf /koolshare/webs/Module_center.asp >/dev/null 2>&1
rm -rf /koolshare/scripts/uninstall_center.sh >/dev/null 2>&1
