#!/bin/sh

/koolshare/scripts/zerotier_config $1
